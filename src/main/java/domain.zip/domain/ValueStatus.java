
package domain;

public enum ValueStatus {
	PENDIENTE, ACEPTADO, DENEGADO
}
